package services;

public class BookApi {

	public static final String API_KEY="AIzaSyBj0UjiEoNRsJHJPpbY6kt0Fa8CGiQR70o";
	public static final String API_URL="www.googleapis.com";
}

	
	

	
